module.exports = {
    'secret': 'ilovenodejs',
};